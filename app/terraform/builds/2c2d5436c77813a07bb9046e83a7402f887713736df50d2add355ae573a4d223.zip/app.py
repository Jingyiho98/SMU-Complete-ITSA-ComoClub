import os
import json
import requests
import boto3


def lambda_handler(event, context):

    CREDENTIALS_ARN = os.environ['MEMBERSON_CREDENTIALS_ARN']
    TOKEN_ARN = os.environ["MEMBERSON_TOKEN_ARN"]

    # Check if correct fields provided
    if ("email" not in event) or ("password" not in event):
        return {"statusCode": 400, "body": json.dumps("Invalid inputs given.")}

    # Retrieve memberson login url
    db = boto3.resource('dynamodb')
    table = db.Table('g2team8-endpoint_db')
    endpoint = table.get_item(Key={'name': 'memberson'})['Item']
    profileUrl = endpoint['api_link'] + '/profile'
    print("URL endpoint retrieved.")

    # Retrieve SSM secrets
    sm = boto3.client(service_name='secretsmanager')

    secret = sm.get_secret_value(
        SecretId=CREDENTIALS_ARN)
    secret = json.loads(secret['SecretString'])

    print(secret)
    token = sm.get_secret_value(
        SecretId=TOKEN_ARN)
    print(token)

    return {
        'statusCode': 200,
        'body': json.dumps({"hi": "Hello"})

    }
