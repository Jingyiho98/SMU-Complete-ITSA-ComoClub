import os
import json
import requests
import boto3


def lambda_handler(event, context):

    # Ping sevenrooms to check if down
    res = requests.get("https://demo.sevenrooms.com/api-ext/2_4/venues")

    if not res.status_code:
        return "SevenRooms is still down."

    nlb_url = os.environ['NLB_URL']

    client = boto3.client('sqs')
    queue = client.get_queue_url(QueueName='failover-queue.fifo')["QueueUrl"]

    # Retrieve messages
    res = client.receive_message(
        QueueUrl=queue, MaxNumberOfMessages=10, VisibilityTimeout=10)

    # End function if no messages found
    if "Messages" not in res.keys():
        return "No messages found"

    # Process messages
    messages = res["Messages"]

    # Iterate through each message and call API
    for message in messages:

        receipt_handle = message["ReceiptHandle"]
        body = message["Body"]
        body = json.loads(body)

        url = body["url"]
        reservation_request = body["reservationRequest"]

        # Retry API call
        res = requests.post("http://" + nlb_url + url,
                            json=reservation_request)

        # Delete message if API recall is successful
        if res.status_code == 200:
            client.delete_message(QueueUrl=queue, ReceiptHandle=receipt_handle)

    return "ok"
