import os
import json
import requests
import boto3


def lambda_handler(event, context):
    print("event", event)
    print("context", context)
    return "hi"
